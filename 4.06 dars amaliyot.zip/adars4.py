with open("text.txt","r") as f1, open("text1.txt","w") as f2:
    for line in f1:
        f2.write(line)

