with open("text.txt","r") as f:
    s=f.readlines()[-1]
    print(s)