with open("text.txt","r") as f:
    l_count=0
    for line in f:
        l_count+=1
print(f"{l_count} ta qator bor")
